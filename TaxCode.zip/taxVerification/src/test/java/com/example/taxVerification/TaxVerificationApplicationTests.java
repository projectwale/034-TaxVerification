package com.example.taxVerification;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaxVerificationApplicationTests {

	@Test
	void contextLoads() {
	}

}
