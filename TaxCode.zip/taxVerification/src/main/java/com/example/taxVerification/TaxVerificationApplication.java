package com.example.taxVerification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaxVerificationApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaxVerificationApplication.class, args);
		
		System.out.print("Project started ....\n");
	}
}
