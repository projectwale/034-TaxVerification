package com.example.taxVerification.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="verifiedData")
public class VerifiedData {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Long id;

	@Column(name="accnumber")
    private String accnumber;
	
	@Column(name="address")
    private String address;
	
	@Column(name="credits")
    private String credits;

	@Column(name="dob")
    private String dob;
	
	@Column(name="duedate")
    private String duedate;
	
	@Column(name="edate")
    private String edate;
	
	@Column(name="file")
    private String file;
	
	@Column(name="fillingstatus")
    private String fillingstatus;
	
	@Column(name="fname")
    private String fname;
	
	@Column(name="income")
    private String income;
	
	@Column(name="sdate")
    private String sdate;
	
	@Column(name="tax")
    private String tax;
	
	@Column(name="taxno")
    private String taxno;
	
	@Column(name="username")
    private String username;
	
	@Column(name="qrpath")
    private String qrpath;
	
	@Column(name="transactionid")
    private String transactionid;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAccnumber() {
		return accnumber;
	}

	public void setAccnumber(String accnumber) {
		this.accnumber = accnumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCredits() {
		return credits;
	}

	public void setCredits(String credits) {
		this.credits = credits;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getDuedate() {
		return duedate;
	}

	public void setDuedate(String duedate) {
		this.duedate = duedate;
	}

	public String getEdate() {
		return edate;
	}

	public void setEdate(String edate) {
		this.edate = edate;
	}

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public String getFillingstatus() {
		return fillingstatus;
	}

	public void setFillingstatus(String fillingstatus) {
		this.fillingstatus = fillingstatus;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getIncome() {
		return income;
	}

	public void setIncome(String income) {
		this.income = income;
	}

	public String getSdate() {
		return sdate;
	}

	public void setSdate(String sdate) {
		this.sdate = sdate;
	}

	public String getTax() {
		return tax;
	}

	public void setTax(String tax) {
		this.tax = tax;
	}

	public String getTaxno() {
		return taxno;
	}

	public void setTaxno(String taxno) {
		this.taxno = taxno;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getQrpath() {
		return qrpath;
	}

	public void setQrpath(String qrpath) {
		this.qrpath = qrpath;
	}

	public String getTransactionid() {
		return transactionid;
	}

	public void setTransactionid(String transactionid) {
		this.transactionid = transactionid;
	}
	
}