package com.example.taxVerification.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.taxVerification.Entity.VerifiedData;

@Repository
public interface VerifiedDataRepository extends JpaRepository<VerifiedData,Long> {
	
    Optional<VerifiedData> findByUsername(String username);  
    
    VerifiedData findByAccnumberAndFnameAndTaxnoAndUsername(String accnumber, String fname, String taxno, String username);
    
    @Modifying
    @Transactional
    @Query("UPDATE VerifiedData v SET v.qrpath = :qrpath WHERE v.username = :username AND v.fname = :fname AND v.taxno = :taxno")
    int updateQrpathByUsernameAndFnameAndTaxno(String qrpath, String username, String fname, String taxno);    

    @Modifying
    @Transactional
    @Query("UPDATE VerifiedData v SET v.transactionid = :transactionid WHERE v.username = :username AND v.fname = :fname AND v.taxno = :taxno")
    int updateTransactionidByUsernameAndFnameAndTaxno(String transactionid, String username, String fname, String taxno);
}
