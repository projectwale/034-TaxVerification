package com.example.taxVerification.Controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.taxVerification.Entity.CombinedDataDTO;
import com.example.taxVerification.Entity.Formdata;
import com.example.taxVerification.Entity.User;
import com.example.taxVerification.Entity.VerifiedData;
import com.example.taxVerification.Repository.FormDataRepository;
import com.example.taxVerification.Repository.UserRepository;
import com.example.taxVerification.Repository.VerifiedDataRepository;
import com.google.zxing.WriterException;

@ComponentScan(basePackages = { "com.example.taxVerification.Controller" })
@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class adminController {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private FormDataRepository formdataRepository;
	@Autowired
	private VerifiedDataRepository verifieddataRepository;
    @Autowired
    private EmailService emailService;

	@GetMapping("/admin/getAllApplication")
	public List<CombinedDataDTO> getAllData() {
		List<Formdata> table1DataList = formdataRepository.findAll();

		List<CombinedDataDTO> combinedDataList = new ArrayList<>();

		for (Formdata table1Data : table1DataList) {
			CombinedDataDTO combinedDataDTO = new CombinedDataDTO();
			combinedDataDTO.setFormdata(table1Data);

			User table2Data = userRepository.findByUsername(table1Data.getUsername());
			if (table2Data != null) {
				combinedDataDTO.setEmail(table2Data.getEmail());
				combinedDataDTO.setMobileNumber(table2Data.getMobile());
			}

			combinedDataList.add(combinedDataDTO);
		}

		return combinedDataList;
	}

	@PostMapping("/admin/verifyUser")
	public String VerifyUser(@RequestBody VerifiedData verifiedData) {

		System.out.print(verifiedData.getUsername() + '\n');

		VerifiedData n = new VerifiedData();

		n.setAccnumber(verifiedData.getAccnumber());
		n.setAddress(verifiedData.getAddress());
		n.setCredits(verifiedData.getCredits());
		n.setDob(verifiedData.getDob());
		n.setDuedate(verifiedData.getDuedate());
		n.setEdate(verifiedData.getEdate());
		n.setFile(verifiedData.getFile());
		n.setFillingstatus(verifiedData.getFillingstatus());
		n.setFname(verifiedData.getFname());
		n.setIncome(verifiedData.getIncome());
		n.setSdate(verifiedData.getSdate());
		n.setTax(verifiedData.getTax());
		n.setTaxno(verifiedData.getTaxno());
		n.setUsername(verifiedData.getUsername());
		n.setQrpath("None");
		n.setTransactionid("None");

		VerifiedData result = verifieddataRepository.save(n);

		if (result != null) {
			User table2Data = userRepository.findByUsername(verifiedData.getUsername());
			if (table2Data != null) {
		        emailService.sendSimpleMessage(table2Data.getEmail(), "Tax verification status", "Your application has been verified. And the calculated tax is RS."+verifiedData.getTax()+", with a due date of "+verifiedData.getDuedate()+".");
				System.out.print("Record inserted");
			}
			return "success";
		} else {
			return "fail";
		}

	}

	@GetMapping("/admin/doesUserExist/{username}")
	public boolean doesUserExist(@PathVariable String username) {
		return verifieddataRepository.findByUsername(username).isPresent();
	}

	@PostMapping("/admin/generateQR")
	public String GenrateQR(@RequestBody Formdata formdata) throws WriterException, IOException {

		System.out.print(formdata.getUsername() + '\n');

		VerifiedData user = verifieddataRepository.findByAccnumberAndFnameAndTaxnoAndUsername(formdata.getAccnumber(),
				formdata.getFname(), formdata.getTaxno(), formdata.getUsername());

		String qrpath = UserService.generateQRCodeImage(user.getFname() + "|" + user.getTaxno() + "|" + user.getIncome()
				+ "|" + user.getDuedate() + "|" + user.getTax());
		
		int updatedRows = verifieddataRepository.updateQrpathByUsernameAndFnameAndTaxno(qrpath, user.getUsername(), user.getFname(), user.getTaxno());
		
        if (updatedRows > 0) {
        	User table2Data = userRepository.findByUsername(user.getUsername());
			if (table2Data != null) {
		        emailService.sendSimpleMessage(table2Data.getEmail(), "Tax verification status", "Your payment method with the QR code is to initialise and make payment before the due date.");
				System.out.print("Record inserted");
			}
			return "success";
        } else {
    		return "fail";
        }

	}
	
	@GetMapping("/admin/getPaymentData")
	public List<VerifiedData> getPaymentData() {
		List<VerifiedData> table1DataList = verifieddataRepository.findAll();
		return table1DataList;
	}

}