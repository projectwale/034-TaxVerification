package com.example.taxVerification.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.taxVerification.Entity.Formdata;
import com.example.taxVerification.Entity.User;

@Repository
public interface FormDataRepository extends JpaRepository<Formdata,Long> {
	
    Optional<Formdata> findByUsername(String username);    
}
