/*
SQLyog Community Edition- MySQL GUI v7.01 
MySQL - 5.0.27-community-nt : Database - tax-verification
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`tax-verification` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `tax-verification`;

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` bigint(20) NOT NULL auto_increment,
  `email` varchar(255) default NULL,
  `fname` varchar(255) default NULL,
  `mobile` varchar(255) default NULL,
  `password` varchar(255) default NULL,
  `username` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`id`,`email`,`fname`,`mobile`,`password`,`username`) values (1,'yashsalvi1999@gmail.com','Yash Salvi','9930090883','yash','yashssalvi'),(2,'roshanmundekar@gmail.com','Roshan mundekar','5485965854','roshan','roshanmund'),(3,'yashsalvi1999@gmail.com','Amol Nerlekar','6589564585','amol','amolnerlekar'),(4,'gaurijaygond@gmail.com','Gauri jaygond','9854587586','gaurijaygond','gaurijaygond');

/*Table structure for table `usertaxdata` */

DROP TABLE IF EXISTS `usertaxdata`;

CREATE TABLE `usertaxdata` (
  `id` bigint(20) NOT NULL auto_increment,
  `file` varchar(255) default NULL,
  `accnumber` varchar(255) default NULL,
  `address` varchar(255) default NULL,
  `credits` varchar(255) default NULL,
  `dob` varchar(255) default NULL,
  `edate` varchar(255) default NULL,
  `fillingstatus` varchar(255) default NULL,
  `fname` varchar(255) default NULL,
  `income` varchar(255) default NULL,
  `sdate` varchar(255) default NULL,
  `taxno` varchar(255) default NULL,
  `username` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `usertaxdata` */

insert  into `usertaxdata`(`id`,`file`,`accnumber`,`address`,`credits`,`dob`,`edate`,`fillingstatus`,`fname`,`income`,`sdate`,`taxno`,`username`) values (1,'FormSign/logo11.png','125485485452','vedika soc sagar nagar vikhroli park site','Education','2024-02-16','2024-02-15','Single','Yash Salvi','499999','2024-01-30','2584584585','yashssalvi'),(2,'FormSign/a.PNG','854854854854','vedika soc sagar nagar vikhroli park site','Child Tax','2024-02-16','2024-02-16','Married Filing Jointly','Amol Nerlekar','99999','2024-02-23','8548548547','amolnerlekar'),(3,'FormSign/ab.png','8596584585458','vedika soc sagar nagar vikhroli park site','Child Tax','2024-02-27','2024-02-22','Single','Gauri jaygond','150000','2024-02-13','8596584585','gaurijaygond');

/*Table structure for table `verified_data` */

DROP TABLE IF EXISTS `verified_data`;

CREATE TABLE `verified_data` (
  `id` bigint(20) NOT NULL auto_increment,
  `accnumber` varchar(255) default NULL,
  `address` varchar(255) default NULL,
  `credits` varchar(255) default NULL,
  `dob` varchar(255) default NULL,
  `duedate` varchar(255) default NULL,
  `edate` varchar(255) default NULL,
  `file` varchar(255) default NULL,
  `fillingstatus` varchar(255) default NULL,
  `fname` varchar(255) default NULL,
  `income` varchar(255) default NULL,
  `qrpath` varchar(255) default NULL,
  `sdate` varchar(255) default NULL,
  `tax` varchar(255) default NULL,
  `taxno` varchar(255) default NULL,
  `transactionid` varchar(255) default NULL,
  `username` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `verified_data` */

insert  into `verified_data`(`id`,`accnumber`,`address`,`credits`,`dob`,`duedate`,`edate`,`file`,`fillingstatus`,`fname`,`income`,`qrpath`,`sdate`,`tax`,`taxno`,`transactionid`,`username`) values (1,'125485485452','vedika soc sagar nagar vikhroli park site','Education','2024-02-16','2024-02-21','2024-02-15','FormSign/logo11.png','Single','Yash Salvi','499999','QR/c3czjnAOg1.png','2024-01-30','1500','2584584585','tok_1OjF6bSDM2aTW7qpwvTBxj5Z','yashssalvi'),(2,'8596584585458','vedika soc sagar nagar vikhroli park site','Child Tax','2024-02-27','2024-02-21','2024-02-22','FormSign/ab.png','Single','Gauri jaygond','150000','QR/bD6MRhpX0K.png','2024-02-13','8500','8596584585','tok_1OjymySDM2aTW7qpFY7fOd1z','gaurijaygond');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
